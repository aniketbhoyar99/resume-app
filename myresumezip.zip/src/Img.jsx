import React from 'react';
import dummy from './Student.jpg';
import './App.css';
const Img = () => {
    return (
<div className="img">
    <img src={dummy} className="miniImg"/>
</div>
    );

}
export default Img;
