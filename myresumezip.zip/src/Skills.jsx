import React from 'react';
import './App.css';
const Skills=()=>{
    return(
<div id="skills">
    <h1>Skills:-</h1>
    <ul className="ul-skills">
        <li>
        <h3> ReactJs</h3>
        </li>
        <li>
        <h3>  core-java</h3>
        </li>
        <li>
        <h3> HTML</h3>
        </li>
        <li>
        <h3> CSS</h3>
        </li>
        <li>
        <h3>JavaScript</h3>
        </li>
        <li>
        <h3> cpp</h3>
        </li>
    </ul>
</div>
    );
}
export default Skills;