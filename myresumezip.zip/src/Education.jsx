import React from 'react';
import './App.css';
const Education = () => {
    return (
        <div id="education">
            <h1>Education :-</h1>
            <ul className="ul-education">
                <li>
                    <h3> 10th Pass</h3>
                </li>
                <li>
                    <h3> 12th Pass</h3>
                </li>
                <li>
                    <h3> Digree in BCA</h3>
                </li>
            </ul>
        </div>
    );
}
export default Education;