import React from 'react';
import './App.css';
const Experience=()=>{
    return(
<div id="experience">
    <h1>Experience:-</h1>
    <ul className="ul-exper">
        <li><h3>As Freshers</h3></li>
    </ul>
    
</div>
    );
}
export default Experience;