import React from 'react';
import './App.css';
const Details = ({ name, mobile, email, address }) => {
    return (
        <div className="det">
            <div className="name">
               <label> Name:- </label>
                {name}
            </div>

            <div className="mobile">
               <label> Mobile No:- </label>
                {mobile}
            </div>

            <div className="email">
                <label> Email:- </label>
                {email}
            </div>

            <div className="address">
                <label> Address:- </label>
                {address}
            </div>

        </div>
    );
}
export default Details;