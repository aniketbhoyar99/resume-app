import Reat from 'react';
import './App.css';
const Navigation=()=>{
    return(
<div className="navigation">
    <a href="#education"><button className="btn1">Education</button></a>
    <a href="#experience"><button className="btn2">Experience</button></a>
    <a href="#skills"><button className="btn3">Skills</button></a>
</div>
    );
}
export default Navigation;