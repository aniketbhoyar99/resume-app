import { getDefaultNormalizer } from '@testing-library/dom';
import React from 'react';
import Img from './Img';
import Mydata from './Mydata';
import './App.css';
import Navigation from './Navigation'
import Education from './Education';
import Experience from './Experience';
import Skills from './Skills';
import Heading from './Heading';
const App = () => {
    // const Product = [{
    //     Name: 'Aniket',
    //     Mobile: 8766832771,
    //     Email: 'aniketbhoyar99@gmail.com',
    //     Address: 'surat'
    // }];
    return (
        <div className="All-Data">
            <Heading className="title"/>
            <div className="mainDiv">
                < Img />
                <Mydata />
            </div>
            <Navigation />
            <div className="education">
                <Education />
            </div>
            <div className="experience">
                <Experience />
            </div>
            <div className="skills">
                <Skills />
            </div>

        </div>

    );
}
export default App;