import React from 'react';
import './App.css';
const Heading =()=>{
return(
<h1 >Resume</h1>
);
}
export default Heading;