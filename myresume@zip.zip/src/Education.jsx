import React from 'react';
import './App.css';
const Education = () => {
    return (
        <div id="education">
            <h1>Education :-</h1>
            <ul className="ul-education">
                <li>
                    <h6>Bachelors In Computer Application[2017-2020]. </h6>  </li>
                <li> <h6>I had Work on College Admition Process ,Project. </h6></li>

            </ul>
        </div>
    );
}
export default Education;