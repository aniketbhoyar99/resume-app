import React from 'react';
import Details from './Details';
import './App.css';
const Mydata =()=>{
    const Product = [{
        Name: 'Aniket',
        Mobile: 8766832771,
        Email: 'aniketbhoyar99@gmail.com',
        Address: 'surat'
    }];
    return(
        <div className="mydata">
        {
            Product.map((value, index) => {
                return (
                <div className="details">
                    < Details name={value.Name}
                        mobile={value.Mobile}
                        email={value.Email}
                        address={value.Address} 
                    />
                      </div>
                );
            })
        }

        </div>
    );
}
export default Mydata;