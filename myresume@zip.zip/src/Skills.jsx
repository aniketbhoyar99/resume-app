import React from 'react';
import './App.css';
const Skills=()=>{
    return(
<div id="skills">
    <h1>Skills:-</h1>
    <ul className="ul-skills">
        <li>
        <h6> ReactJs</h6>
        </li>
        <li>
        <h6>  core-java</h6>
        </li>
        <li>
        <h6> HTML</h6>
        </li>
        <li>
        <h6> CSS</h6>
        </li>
        <li>
        <h6>JavaScript</h6>
        </li>
        <li>
        <h6> cpp</h6>
        </li>
    </ul>
</div>
    );
}
export default Skills;