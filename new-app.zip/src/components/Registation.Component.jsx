import React from 'react';
const Registation = () => {
    return (
        <div style={{ borderColor: "black", border: "2px solid", width: "50%" }}>
            <div>
                <h1>Registation</h1>
            </div>
            <div>
                <label>Email : </label>
                <input type="text" /><br />
                <label>Name : </label>
                <input type="text" /><br />
                <label>Password : </label>
                <input type="text" /><br />
                <label>Contact no : </label>
                <input type="text" /><br />
                <button>Register</button>
            </div>
        </div>
    );
}
export default Registation;