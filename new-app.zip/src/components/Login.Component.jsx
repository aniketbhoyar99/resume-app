import React from 'react';

const Login = () => {
    return (
        <div className="main-login-div" >
            <div>
                <h1>Login</h1>
            </div>
            <div>
                <label>Email : </label>
                <input type="text" /><br />
                <label>Password : </label>
                <input type="text" /><br />
                <button>Login</button>
            </div>
        </div>
    );
}
export default Login;