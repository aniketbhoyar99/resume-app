const Login = () => {
    return (
        <div className="main-login-div" >
            <div>
                <h1>Login</h1>
            </div>
            <div>
                <label for="email">Email : </label>
                <input type="text" /><br />
                <label fro="password">Password : </label>
                <input type="text" /><br />
                <button>Login</button>
            </div>
        </div>
    );
}
export default Login;