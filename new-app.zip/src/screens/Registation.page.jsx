const Registation = () => {
    return (
        <div style={{ borderColor: "black", border: "2px solid", width: "50%" }}>
            <div>
                <h1>Registation</h1>
            </div>
            <div>
                <label for="email">Email : </label>
                <input type="text" /><br />
                <label for="name">Name : </label>
                <input type="text" /><br />
                <label for="password">Password : </label>
                <input type="text" /><br />
                <label for="contact no">Contact no : </label>
                <input type="text" /><br />
                <button>Register</button>
            </div>
        </div>
    );
}
export default Registation;