// import React, { useState } from 'react';
// import Login from './components/Login.Component'
// import Registation from './components/Registation.Component'
// const App = () => {
//     const [pagelogin, setPageLogin] = useState('login');
//     const onClickHandler = (value) => {
//         setPageLogin(value)
//     }
//     return (
//         <div>
//             <div>
//                 <input type="radio" id="login" name="login" defualtChecked onClick={() => { onClickHandler('login') }} />
//                 <label htmlFor="login">Login</label>
//                 <input type="radio" id="registation" name="login" onClick={() => { onClickHandler('register') }} />
//                 <label htmlFor="registation">Registation</label>

//             </div>
//             {pagelogin == 'login' ? <Login /> : <Registation />}
//         </div>
//     )
// }

// export default App;

import { BrowserRouter, Link, Route } from 'react-router-dom';
import Login from './screens/Login.Page';
import Registation from './screens/Registation.page';
const App = () => {
    return (
        <BrowserRouter>
            <div>
                <Link to="/">Login</Link>
                <Link to="/Registation">Registation</Link>
            </div>
            <Route exact path="/">
                <Login />
            </Route>
            <Route path="/Registation">
                <Registation />
            </Route>
        </BrowserRouter>
    );
}
export default App;
