import { createStore } from 'redux'
import { rootReducer } from './store/reducers/indexReducer.reducer'

export const store = createStore(rootReducer)
