
const initialState = 0
export const counterHandler = (state = initialState, action) => {
    switch (action.type) {
        case 'INCREMENT':
            console.log("true");
            return state = state + 1
        case 'DECREMENT':
            console.log("true");
            return state = state - 1
        default:
            console.log("defalt");
            return state;
    }

}