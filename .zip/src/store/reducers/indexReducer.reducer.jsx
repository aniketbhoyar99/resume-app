import { combineReducers } from 'redux'
import { counterHandler } from './counter.reducer'
import { ToDo } from './ToDo.reducers'


export const rootReducer = combineReducers({
    counterHandler,
    ToDo
})