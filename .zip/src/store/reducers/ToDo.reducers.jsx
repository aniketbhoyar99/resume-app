const initialState = {
    Data: []
}
export const ToDo = (state = initialState, action) => {
    switch (action.type) {
        case 'TODO':
            console.log("todo true");
            const myState = state.Data
            myState.push(action.payload)
            console.log("---->", myState);
            return state
        default:
            console.log("?????????");
            return state
    }

}