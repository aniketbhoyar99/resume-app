export const incrementHandlerAction = (num) => {
    return {
        type: 'INCREMENT',
        payload: num
    }
}
export const DecrementHandlerAction = (num) => {
    return {
        type: 'DECREMENT',
        payload: num
    }
}
export const changeHandler = (load) => {
    return {
        type: 'TODO',
        payload: load
    }
}
