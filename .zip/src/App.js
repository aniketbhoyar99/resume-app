import React from 'react'
import { useDispatch } from 'react-redux'
import { useSelector } from 'react-redux'
import Counter from './Components/class.component'
import ReduxCounter from './Components/ReduxCounter'
import ReduxToDo from './Components/ReduxToDo'
import ToDoApp from './Components/ToDoApp.component'
import { DecrementHandlerAction, incrementHandlerAction } from './store/action/increment.action'

const App = () => {
  arr=[1,2,3,4,1,3,5,6,2]

  return (

    <div>
      {
        arr.filter((val,index)=>{
          return(
            <div>
           <h1>{val}</h1>
            </div>
          )
        })
       
      }
    </div>
   
  )

}

export default App
