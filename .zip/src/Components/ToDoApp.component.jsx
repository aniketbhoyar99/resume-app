import React, { useState } from 'react'

const ToDoApp = () => {
    const [inputedData, setInputedData] = useState()
    const [submitedData, setSubmitedData] = useState([])

    const displayData = (e) => {
        let val = e.target.value
        setInputedData(val)
    }
    const SubmitHandler = () => {
        setSubmitedData([...submitedData, inputedData])
    }
    const deleteHandler = (subvalues) => {
        console.log("-->", subvalues);
        setSubmitedData(submitedData.filter((value) => {
            return value != subvalues
        }))
    }
    return (
        <div>
            <input type="text" onChange={displayData} name="text" />
            <button onClick={SubmitHandler}>submit</button>
            {
                submitedData.map((subvalues) => {
                    return (
                        <div>
                            <h1>{subvalues}<button onClick={() => { deleteHandler(subvalues) }}>delete</button></h1>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default ToDoApp
