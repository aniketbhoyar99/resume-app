import React from 'react'
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { DecrementHandlerAction, incrementHandlerAction } from '../store/action/increment.action';

const ReduxCounter = () => {
    const myState = useSelector((state) => state.counterHandler)
    console.log("-------------->", myState);
    const dispatch = useDispatch();

    const myFun = () => {
        dispatch(incrementHandlerAction(1))
    }
    return (
        <div>
            <button onClick={myFun} className="btn btn-primary">+</button>
            <input type="text" value={myState} />
            <button onClick={() => dispatch(DecrementHandlerAction(1))}>-</button>
        </div>
    )

}

export default ReduxCounter
