import React from 'react';
class Counter extends React.Component {
    Component = '';
    state = {
        mainCounter: 0
    };

    constructor(props) {
        super(props)
        this.increament = this.increament.bind(this);
        this.decreament = this.decreament.bind(this);
    }
    increament() {
        if (this.state.mainCounter < 13) {
            this.setState({ mainCounter: this.state.mainCounter + 1 });
        }
    }
    decreament() {

        if (this.state.mainCounter > 0) {
            this.setState({ mainCounter: this.state.mainCounter - 1 });
        }
        // alert(this.state.mainCounter)
    }

    render() {
        return (
            <div className="form-control">
                <p>{this.component}</p>
                <p>{this.state.mainCounter}</p>
                <button onClick={this.increament}>+</button>
                <button onClick={this.decreament}>-</button>
            </div>
        );
    }
}
export default Counter;