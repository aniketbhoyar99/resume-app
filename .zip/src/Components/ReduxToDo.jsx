import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { changeHandler } from '../store/action/increment.action'

const ReduxToDo = () => {
    const [stateValue, setStateValue] = useState()
    const [displayData, setDisplayData] = useState([]);
    let MyVal = useSelector((state) => state.ToDo.Data)
    const dispatch = useDispatch()
    const changing = (e) => {
        let num = e.target.value
        setStateValue(num)
        console.log(stateValue);
    }
    const showToDo = () => {
        dispatch(changeHandler(stateValue))
        setDisplayData(MyVal);
        setStateValue('');
        console.log("--", MyVal);
    }
    const deleteItem = (val) => {

    }
    return (
        <div>
            <input type="text" onChange={changing} value={stateValue} />
            <button onClick={showToDo}>show</button>

            {displayData.map((val) => {
                return (
                    <div>
                        <h6>{val}<button onClick={() => deleteItem(val)}>del</button></h6>
                    </div>
                )
            })}
        </div>
    )
}

export default ReduxToDo
