import React from 'react'
import { Link} from "react-router-dom";

function Products({data,title}) {
    return (
        
        <div className="col-12 col-md-4 mb-4">
        <div className="card h-70">
          <Link to="/shop-single">
            <img src={data} className="card-img-top"  alt="..." />
          </Link>
          <div className="card-body">
            <ul className="list-unstyled d-flex justify-content-between">
              <li>
                <i className="text-warning fa fa-star" />
                <i className="text-warning fa fa-star" />
                <i className="text-warning fa fa-star" />
                <i className="text-muted fa fa-star" />
                <i className="text-muted fa fa-star" />
              </li>
              <li className="text-muted text-right">$240.00</li>
            </ul>
            <Link to="/shop-single" className="h2 text-decoration-none text-dark">{title}</Link>
            <p className="card-text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt in culpa qui officia deserunt.
        </p>
            <p className="text-muted">Reviews (24)</p>
          </div>
        </div>
      
        </div>
    )
}

export default Products;
