import React from 'react';
import About from './screens/About.screens';
import Contact from './screens/Contact.screens';
import Home from './screens/Home.screens';
import Shop from './screens/Shop.screens';
import ShopSingle from './screens/ShopSingle.screens';
import { BrowserRouter, Switch, Route, Link } from "react-router-dom";
import Products from '././component/Products.component';


const App = () => {
  return (
    // <Products />
  <BrowserRouter>

    <Switch>
      <Route exact path="/">
        <Home/>
      </Route>
      <Route path="/about">
        <About />
      </Route>
      <Route path="/contact"><Contact />
      </Route>
      <Route path="/shop-single"><ShopSingle />
      </Route>
      <Route path="/shop"><Shop />
      </Route>
      <Route path="/products"><Products />
      </Route>
    </Switch>
  </BrowserRouter>
  );
}

export default App;